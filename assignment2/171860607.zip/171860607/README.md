> Jinbin Bai <jinbin5bai@gmail.com> 

> May 2021

## For Edge Detection Code, you just need to 'cd' to evaluateSegmentation.m and run it. The parameters are listed in our report.

## For Image Segmentation, you just need to 'cd' to egmentMain.m and run it. By the way, in this file, we list all the plot without comment on them. So if you just need to reveal one of them, feel free to comment other parts of this file.

## If there is any question, feel free to contact me via email.

