### Computer Vision homework including Image Mosaics and Automatic Image Mosaics
Just need to change the code in the main function if you want. More details about the code are reported in the report.